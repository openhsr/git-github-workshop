# An example Project

This is an example project - to play around with in the open\HSR Git/Github workshop.
