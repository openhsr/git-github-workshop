(function() {
    'use strict';
    document.querySelector('aside > img').addEventListener('click', function(){
        alert("Git is awesome!");
    });
}());
